For the Changelog, please see [Releases](https://github.com/phusion/baseimage-docker/releases) on GitHub
