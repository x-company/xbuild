baseimage-docker-nsenter is the nsenter tool taken from https://github.com/jpetazzo/nsenter, commit 10ce18a7a32. It has been stripped in order to make it smaller.
