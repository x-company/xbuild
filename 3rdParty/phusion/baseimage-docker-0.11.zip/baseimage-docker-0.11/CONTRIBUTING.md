Hey, thanks for wanting to contribute to baseimage-docker. :)

If you have a question, please use the [discussion forum](https://groups.google.com/d/forum/passenger-docker). The Github issue tracker is only for **bug reports and feature requests**.

If you want to develop baseimage-docker, use the Vagrantfile in the repository. It will setup an Ubuntu VM with Docker installed in it. Use the Makefile to build the Docker image.

All development happens on the `next` branch. The `master` branch is supposed to point to the latest stable release, because users read documentation from the `master` branch.
